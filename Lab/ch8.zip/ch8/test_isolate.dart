import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:async';
import 'dart:convert';
import 'dart:isolate';

void main() {
  runApp(SampleApp());
}

class SampleApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sample App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: IsolateScreen(),
    );
  }
}

class IsolateScreen extends StatefulWidget {
  @override
  IsolateScreenState createState() => IsolateScreenState();
}

class IsolateScreenState extends State<IsolateScreen> {
  

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Isolate Example'),
        ),
        body: 
    );
  }
}
